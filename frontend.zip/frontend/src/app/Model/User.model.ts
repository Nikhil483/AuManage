export default interface User {
    email: string;
    name: string;
    photoUrl: string;
  }
  