export default interface Token {
  accessToken: string;
  email: string;
}
