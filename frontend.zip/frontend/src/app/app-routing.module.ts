import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { MainNavComponent } from './main-nav/main-nav.component';
import { CreateComponent } from './create/create.component';
import { EditComponent } from './edit/edit.component';
import { DeleteComponent } from './delete/delete.component';
import { SearchComponent } from './search/search.component';
import { TrendsComponent } from './trends/trends.component';
import { LoginGuard } from './login.guard';
import { GuardGuard } from '../Guard/guard.guard';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: '/home' },
  { path: 'home', component: HomeComponent, canActivate: [LoginGuard] },
  { path: 'edit', component: EditComponent, canActivate: [GuardGuard] },
  { path: 'search', component: SearchComponent, canActivate: [GuardGuard]},
  { path: 'create', component: CreateComponent, canActivate: [GuardGuard] },
  { path: 'trends', component: TrendsComponent, canActivate: [GuardGuard] },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
